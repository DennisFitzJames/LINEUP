# -*- mode: python ; coding: utf-8 -*-


a = Analysis(
    ['C:\\Free Form Labels\\zebra_label_app_v4.py'],
    pathex=[],
    binaries=[],
    datas=[('C:\\Free Form Labels\\feather.ico', '.')],
    hiddenimports=[],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name='Zebra Label Printer',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=['C:\\Free Form Labels\\feather.ico'],
)
